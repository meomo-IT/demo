Install docker and docker compose and run: 

```
docker-compose up
```

Access to `localhost:8000`, if have other process run in this port, you need stop this process.
