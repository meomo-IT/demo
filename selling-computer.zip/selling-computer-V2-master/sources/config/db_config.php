<?php

define('DB_NAME', 'selling_computer');
define('DB_USER', 'trannguyenhan');
define('DB_PASSWORD', 'mysql12345');
define('DB_HOST', 'db');
define('DB_PORT', "3306");
