# selling-computer
E-commerce website sells and reviews computers with pure PHP (not using framework)

---
Install :
```
install PHP : sudo apt-get install php7.4
install Apache2 : sudo apt-get install apache2
install library apache2 for php : sudo apt-get install libapache2-mod-php7.4
restart apache2 : sudo systemctl restart apache2
clone project from github to Root Document of Apache2 : git clone https://github.com/trannguyenhan/selling-computer.git
Open with your browser with path : localhost/selling-computer
```
---
## Demo website
### Home page :

![](https://i.pinimg.com/originals/bc/b8/32/bcb83294490433e27cb99dca1a18c1bd.png)

### About page :

![](https://i.pinimg.com/originals/fe/c0/b2/fec0b24dadb462b284d907039363214c.png)

### Profile page :

![](https://i.pinimg.com/originals/38/2f/d8/382fd83280c31e5838c761aecf00ca4c.png)

### Cart page: 

![](https://i.pinimg.com/originals/13/63/b9/1363b9b0ab3ac057043b574580d69676.png)

### Login page :
![](https://i.pinimg.com/originals/07/7f/3f/077f3fea59f763e44d35d03d9f21e114.png)
